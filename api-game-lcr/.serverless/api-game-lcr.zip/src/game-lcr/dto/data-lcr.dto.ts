export class DataLcrDto {
    input: string
}