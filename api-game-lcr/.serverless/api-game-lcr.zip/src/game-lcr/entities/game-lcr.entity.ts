export class GameLcr {}
